using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Define Report Directory
$folderName = 'azqrReports'

# Ensure directory exists
if (-Not (Test-Path -Path $folderName -PathType Container)) {
    try {
        New-Item -ItemType Directory -Path $folderName -Force | Out-Null
        Write-Output "Directory '$folderName' created successfully."
    } catch {
        Write-Error "Failed to create directory '$folderName': $_"
        exit 1
    }
} 

# Azure Quick Review Download
Write-Output "Downloading Azure Quick Review..."
try {
    $azQRLatestReleaseTagUrl = 'https://api.github.com/repos/Azure/azqr/releases/latest'
    $azQRLatestReleaseTag = (Invoke-RestMethod -Uri $azQRLatestReleaseTagUrl).tag_name
    $azQRDownloadUrl = "https://github.com/Azure/azqr/releases/download/$azQRLatestReleaseTag/azqr-ubuntu-latest-amd64"
    
    Invoke-WebRequest -Uri $azQRDownloadUrl -OutFile "./$folderName/azqr"
    chmod +x "./$folderName/azqr"
    Write-Output "Azure Quick Review downloaded successfully."
} catch {
    Write-Error "Failed to download Azure Quick Review: $_"
    exit 1
}

# Azure Quick Review - Execute
Write-Output "Executing Azure Quick Review Scan..."
try {
    $env:AZURE_ORG_NAME = (Get-MgOrganization).DisplayName
    $env:AZURE_TENANT_ID = (Get-AzContext).Tenant.Id
    $env:AZURE_CLIENT_ID = $env:managedIdentityId
    
    ./azqr scan
    $azQuickReviewFilePath = (Get-ChildItem -Path *.xlsx | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
    Write-Output "Azure Quick Review scan completed successfully."
} catch {
    Write-Error "Azure Quick Review execution failed: $_"
    exit 1
}

# Email Configuration
if ($env:emailEnabled) {
    Write-Output `r "Sending the report via email..."
    try {
        # Fetch environment variables
        $smtpServer = $env:emailSMTPServer
        $smtpPort = $env:emailSMTPServerPort
        $smtpUser = $env:emailSMTPAuthUserName
        $smtpPassword = $env:emailSMTPAuthPassword

        # Email details
        $from = $env:emailSender
        $to = $env:emailRecipient
        $date = Get-Date -Format 'MMMM yyyy'
        $subject = "[Azure Quick Review] - New Advisory Report - $date"
        $body = """
        Hello,

        This is your Azure Quick Review report.
        Tenant Name: $env:AZURE_ORG_NAME
        Tenant ID: $env:AZURE_TENANT_ID

        Please find the detailed findings in the attached report.

        Best regards,
        Azure Quick Review Automation
        """

        # Create email message
        $emailMessage = New-Object System.Net.Mail.MailMessage($from, $to, $subject, $body)
        $emailMessage.IsBodyHtml = $false
        $emailMessage.Priority = [System.Net.Mail.MailPriority]::High

        # Add attachment if available
        if ($azQuickReviewFilePath) {
            $attachment = New-Object System.Net.Mail.Attachment -ArgumentList $azQuickReviewFilePath
            $emailMessage.Attachments.Add($attachment)
        }

        # Configure SMTP client
        $smtpClient = New-Object System.Net.Mail.SmtpClient($smtpServer, $smtpPort)
        $smtpClient.Credentials = New-Object System.Net.NetworkCredential($smtpUser, $smtpPassword)
        $smtpClient.EnableSsl = $true
        
        # Send email
        $smtpClient.Send($emailMessage)
        Write-Output `r "Email sent successfully."
        
        # Cleanup
        $emailMessage.Dispose()
        if ($attachment) { $attachment.Dispose() }
    } catch {
        Write-Error "Failed to send email: $_"
        exit 1
    }
}